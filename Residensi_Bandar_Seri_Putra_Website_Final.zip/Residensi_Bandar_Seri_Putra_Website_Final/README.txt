RESIDENSI BANDAR SERI PUTRA WEBSITE

Open index.html to preview.
Upload index.html and the images folder to your web hosting public_html folder.

Includes responsive design, project details, facilities, Type A1 floor plan, location section, registration form and WhatsApp lead generation to +60 13-439 3435.
